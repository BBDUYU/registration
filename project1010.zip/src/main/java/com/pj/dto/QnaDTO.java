package com.pj.dto;


public class QnaDTO {
	private int QnaNum;
	private String title;
	private String writer;
	private String type;
	private String day;
	private String content;
	private int StudentNum;
	
	private String answer;
	private String answerday;
	private String answerer;
	
	public int getQnaNum() {
		return QnaNum;
	}
	public void setQnaNum(int qnaNum) {
		QnaNum = qnaNum;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getStudentNum() {
		return StudentNum;
	}
	public void setStudentNum(int studentNum) {
		StudentNum = studentNum;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getAnswerday() {
		return answerday;
	}
	public void setAnswerday(String answerday) {
		this.answerday = answerday;
	}
	public String getAnswerer() {
		return answerer;
	}
	public void setAnswerer(String answerer) {
		this.answerer = answerer;
	}
	
	
}
	
	
	
	